BASE64_STORE = {}
url_time = {}